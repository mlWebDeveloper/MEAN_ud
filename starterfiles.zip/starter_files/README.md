From the command line navigate to this folder and run:
1. npm install
2. bower install

In the server folder run:
- nodemon app 
OR 
- nodemon app.js

And navigate to http://localhost:9000
